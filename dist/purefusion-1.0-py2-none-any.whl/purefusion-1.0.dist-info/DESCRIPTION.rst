Pure Fusion is fully API-driven. Most APIs which change the system (POST, PATCH, DELETE) return an Operation in status \&quot;Pending\&quot; or \&quot;Running\&quot;. You can poll (GET) the operation to check its status, waiting for it to change to \&quot;Succeeded\&quot; or \&quot;Failed\&quot;.   # noqa: E501


